export const AddAddressContent = {
  tenant:"Tell us about the property you want assistance for",
  landlord: "Your office or registered address"
}