export const OtpPageContent = {
  // TODO new line
  tenant: (
    <>
      <p>Many people have suffered economically in recent times.</p>
      <p>
        We are here to assist you in getting financial aid through Indianapolis
        Rental Assistance Program
      </p>
    </>
  ),
  landlord: `
  Easily manage applications on all your properties
  `,
};
