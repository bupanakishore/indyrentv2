export const VerifyPhoneContent = {
  landlord: {
    header: "Are you a propery owner, manager or a company?",
    prompt: "We need this info to verify your account",
  },
  tenant: {
    header: "Are you a tenant looking for rental assistance?",
    prompt: "Enter Tenant Details below",
  },
};